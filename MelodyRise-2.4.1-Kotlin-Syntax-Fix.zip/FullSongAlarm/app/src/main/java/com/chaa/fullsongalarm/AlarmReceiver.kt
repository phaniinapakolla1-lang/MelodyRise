package com.chaa.fullsongalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val id = intent?.getIntExtra("alarm_id", -1) ?: -1
        if (id < 0) return
        val isSnooze = intent?.getBooleanExtra("snooze", false) ?: false
        val alarm = AlarmStore.all(context).firstOrNull { it.id == id && (it.enabled || isSnooze) } ?: return
        val serviceIntent = Intent(context, MusicPlaybackService::class.java).putExtra("alarm_id", id)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(serviceIntent)
        else context.startService(serviceIntent)
        if (!isSnooze) {
            if (alarm.daily) {
                AlarmStore.schedule(context, alarm)
            } else {
                AlarmStore.setEnabled(context, id, false)
            }
        }
    }
}
