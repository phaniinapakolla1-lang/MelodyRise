package com.chaa.fullsongalarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat

class MusicPlaybackService : Service() {
    private var player: MediaPlayer? = null
    private var currentAlarmId: Int = -1

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopPlayback()
            return START_NOT_STICKY
        }
        val id = intent?.getIntExtra("alarm_id", -1) ?: -1
        if (id < 0) { stopSelf(); return START_NOT_STICKY }
        val alarm = AlarmStore.all(this).firstOrNull { it.id == id }
        if (alarm == null) { stopSelf(); return START_NOT_STICKY }
        if (player?.isPlaying == true && currentAlarmId == id) return START_NOT_STICKY
        startForeground(NOTIFICATION_ID, makeNotification(alarm.songName, id))
        try {
            player?.release()
            currentAlarmId = id
            player = MediaPlayer().apply {
                setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                setDataSource(applicationContext, Uri.parse(alarm.songUri))
                setOnCompletionListener { stopPlayback() }
                setOnErrorListener { _, _, _ -> stopPlayback(); true }
                setOnPreparedListener { it.start() }
                prepareAsync()
            }
        } catch (_: Exception) { stopPlayback() }
        return START_NOT_STICKY
    }

    private fun makeNotification(songName: String, id: Int): Notification {
        val channelId = "full_song_alarm_playback"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm.getNotificationChannel(channelId) == null) {
            nm.createNotificationChannel(NotificationChannel(channelId, "Song alarm playback", NotificationManager.IMPORTANCE_HIGH))
        }
        val stopIntent = PendingIntent.getService(this, 3000 + id,
            Intent(this, MusicPlaybackService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val openIntent = PendingIntent.getActivity(this, 4000 + id,
            Intent(this, FullScreenAlarmActivity::class.java).putExtra("alarm_id", id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Full Song Alarm is playing")
            .setContentText(songName)
            .setContentIntent(openIntent)
            .setFullScreenIntent(openIntent, true)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopIntent)
            .build()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }

    private fun stopPlayback() {
        player?.setOnCompletionListener(null)
        player?.release()
        player = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    companion object {
        private const val NOTIFICATION_ID = 22
        const val ACTION_STOP = "com.chaa.fullsongalarm.STOP_MUSIC"
    }
}
