package com.chaa.fullsongalarm

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.graphics.BitmapFactory
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAlarm
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.*
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar
import java.util.Locale

private val Night = Color(0xFF10131F)
private val NightPanel = Color(0xFF1B2030)
private val Lilac = Color(0xFF9B8CFF)
private val MintAccent = Color(0xFF9DF0D0)

class MainActivity : ComponentActivity() {
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PermissionGate(resumeTick = resumeTick) { AlarmHome() } }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }
}

private data class PermissionStatus(val notifications: Boolean, val exactAlarms: Boolean, val fullScreen: Boolean) {
    val allGranted: Boolean get() = notifications && exactAlarms && fullScreen
}

private fun permissionStatus(context: Context): PermissionStatus {
    val notifications = Build.VERSION.SDK_INT < 33 ||
        context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    val exact = Build.VERSION.SDK_INT < 31 ||
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
    val fullScreen = Build.VERSION.SDK_INT < 34 ||
        context.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
    return PermissionStatus(notifications, exact, fullScreen)
}

@Composable
private fun PermissionGate(resumeTick: Int, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val activity = context as? ComponentActivity
    var status by remember { mutableStateOf(permissionStatus(context)) }
    var note by remember { mutableStateOf("Allow these permissions so alarms can ring on time and show the alarm screen.") }
    LaunchedEffect(resumeTick) { status = permissionStatus(context) }
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        status = permissionStatus(context)
        note = if (granted) "Notification permission granted." else "Notifications are required for alarm alerts. Please allow them to continue."
    }

    if (status.allGranted) {
        content()
    } else {
        val dark = true
        MaterialTheme(colorScheme = darkColorScheme(primary = Lilac, secondary = MintAccent)) {
            Surface(Modifier.fillMaxSize(), color = Night) {
                Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
                    Icon(Icons.Default.AddAlarm, contentDescription = null, tint = MintAccent, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(16.dp))
                    Text("Set up alarm permissions", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(8.dp))
                    Text("Before opening Full Song Alarm, enable the permissions below. Android requires you to approve some of them in Settings.", color = Color(0xFFB6B9CA))
                    Spacer(Modifier.height(18.dp))
                    PermissionRow("Notifications", status.notifications, "Shows the alarm notification and Stop action")
                    PermissionRow("Exact alarms", status.exactAlarms, "Helps your alarm run at the scheduled time")
                    PermissionRow("Full-screen alarm", status.fullScreen, "Allows the alarm screen to appear over the lock screen")
                    Spacer(Modifier.height(16.dp))
                    if (!status.notifications && Build.VERSION.SDK_INT >= 33) {
                        Button(onClick = { notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }, modifier = Modifier.fillMaxWidth()) { Text("Allow notifications") }
                        Spacer(Modifier.height(8.dp))
                    }
                    if (!status.exactAlarms && Build.VERSION.SDK_INT >= 31) {
                        OutlinedButton(onClick = {
                            try { activity?.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).setData(Uri.parse("package:${context.packageName}"))) }
                            catch (_: Exception) { activity?.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))) }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Allow exact alarms in Settings") }
                        Spacer(Modifier.height(8.dp))
                    }
                    if (!status.fullScreen && Build.VERSION.SDK_INT >= 34) {
                        OutlinedButton(onClick = {
                            try { activity?.startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT).setData(Uri.parse("package:${context.packageName}"))) }
                            catch (_: Exception) { activity?.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))) }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Allow full-screen alarm in Settings") }
                        Spacer(Modifier.height(8.dp))
                    }
                    OutlinedButton(onClick = { status = permissionStatus(context); note = if (permissionStatus(context).allGranted) "All required permissions are ready." else "Some permissions are still missing. Enable them above, then tap Recheck." }, modifier = Modifier.fillMaxWidth()) { Text("Recheck permissions") }
                    Spacer(Modifier.height(10.dp))
                    Text(note, color = Color(0xFFB6B9CA), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun PermissionRow(title: String, granted: Boolean, detail: String) {
    Card(colors = CardDefaults.cardColors(containerColor = NightPanel), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold)
                Text(detail, color = Color(0xFFB6B9CA), fontSize = 12.sp)
            }
            Text(if (granted) "ALLOWED ✓" else "MISSING", color = if (granted) MintAccent else Color(0xFFFFA6A6), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AlarmHome() {
    val context = LocalContext.current
    var alarms by remember { mutableStateOf(AlarmStore.all(context)) }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedName by remember { mutableStateOf("") }
    val initialTime = remember { Calendar.getInstance().apply { add(Calendar.MINUTE, 1) } }
    var hour by remember { mutableIntStateOf(initialTime.get(Calendar.HOUR_OF_DAY)) }
    var minute by remember { mutableIntStateOf(initialTime.get(Calendar.MINUTE)) }
    var daily by remember { mutableStateOf(true) }
    val uiPrefs = remember { context.getSharedPreferences("ui", Context.MODE_PRIVATE) }
    var themeChoice by remember { mutableStateOf(uiPrefs.getString("theme", "DARK") ?: "DARK") }
    var timeFormat by remember { mutableStateOf(uiPrefs.getString("time_format", "12H") ?: "12H") }
    var wallpaperChoice by remember { mutableStateOf(uiPrefs.getString("wallpaper", "AURORA") ?: "AURORA") }
    var wallpaperUri by remember { mutableStateOf(uiPrefs.getString("wallpaper_uri", null)) }
    var showWallpaperMenu by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var glassStrength by remember { mutableFloatStateOf(uiPrefs.getFloat("glass_strength", 0.48f)) }
    var accentHex by remember { mutableStateOf(uiPrefs.getString("accent_hex", "#9B8CFF") ?: "#9B8CFF") }
    var textHex by remember { mutableStateOf(uiPrefs.getString("text_hex", "") ?: "") }
    var showTimePicker by remember { mutableStateOf(false) }
    var showNameDialog by remember { mutableStateOf(!uiPrefs.getBoolean("name_prompt_seen", false)) }
    var showEditNameDialog by remember { mutableStateOf(false) }
    var nameInput by remember { mutableStateOf(uiPrefs.getString("display_name", "") ?: "") }
    var message by remember { mutableStateOf("Add a song and schedule as many alarms as you need.") }
    val glass = themeChoice == "GLASS"
    val accent = try { Color(android.graphics.Color.parseColor(accentHex)) } catch (_: Exception) { Lilac }
    val light = when (themeChoice) { "LIGHT" -> true; "SYSTEM" -> !isSystemInDarkTheme(); else -> false }
    val bg = if (light) Color(0xFFF5F4FA) else Night
    val panel = if (glass) (if (light) Color.White.copy(alpha = glassStrength) else Color(0xFF171727).copy(alpha = glassStrength)) else if (light) Color.White else NightPanel
    val greeting = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..20 -> "Good evening"
        else -> "Hello"
    }
    val greetingLine = nameInput.trim().takeIf { it.isNotEmpty() }?.let { "$greeting, $it!" } ?: "$greeting!"
    val text = if (textHex.isNotBlank()) (try { Color(android.graphics.Color.parseColor(textHex)) } catch (_: Exception) { if (light) Color(0xFF1C1B24) else Color.White }) else if (light) Color(0xFF1C1B24) else Color.White
    val muted = if (light) Color(0xFF666477) else Color(0xFFB6B9CA)
    val wallpaperPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            wallpaperUri = uri.toString()
            wallpaperChoice = "LOCAL"
            uiPrefs.edit().putString("wallpaper", "LOCAL").putString("wallpaper_uri", uri.toString()).apply()
            message = "Background wallpaper updated."
        }
    }
    val wallpaperBitmap = remember(wallpaperUri, wallpaperChoice) {
        if (wallpaperChoice == "LOCAL" && wallpaperUri != null) {
            try { context.contentResolver.openInputStream(Uri.parse(wallpaperUri!!))?.use { BitmapFactory.decodeStream(it)?.asImageBitmap() } } catch (_: Exception) { null }
        } else null
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            selectedUri = uri
            selectedName = displayName(context, uri) ?: "Selected MP3"
            message = "Selected: $selectedName"
        }
    }

    MaterialTheme(colorScheme = if (light) lightColorScheme(primary = accent, secondary = MintAccent) else darkColorScheme(primary = accent, secondary = MintAccent, background = Night, surface = NightPanel)) {
        Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
          Box(Modifier.fillMaxSize()) {
            if (wallpaperBitmap != null && wallpaperChoice == "LOCAL") {
                Image(bitmap = wallpaperBitmap!!, contentDescription = "Selected background wallpaper", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(if (light) Color.White.copy(alpha = if (glass) 0.16f else 0.38f) else Color(0xFF090B16).copy(alpha = if (glass) 0.16f else 0.34f)))
            } else {
                val wallpaperBrush = when (wallpaperChoice) {
                    "OCEAN" -> Brush.verticalGradient(listOf(Color(0xFF064E68), Color(0xFF101B3C), bg))
                    "SUNSET" -> Brush.verticalGradient(listOf(Color(0xFFFF9A76), Color(0xFF8D477D), Color(0xFF24264B)))
                    "FOREST" -> Brush.verticalGradient(listOf(Color(0xFF174A3A), Color(0xFF172D32), bg))
                    "MIDNIGHT" -> Brush.verticalGradient(listOf(Color(0xFF34306D), Color(0xFF16182C), bg))
                    else -> Brush.linearGradient(listOf(Color(0xFF392F70), Color(0xFF151A31), bg))
                }
                Box(Modifier.fillMaxSize().background(wallpaperBrush))
            }
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(accent, MintAccent)), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.MusicNote, null, tint = Night, modifier = Modifier.size(28.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("MELODYRISE", color = text, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp)
                        Text("Wake up to your favourite music", color = muted, fontSize = 12.sp)
                    }
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        IconButton(onClick = { expanded = true }) { Icon(Icons.Default.MoreVert, contentDescription = "More options", tint = accent) }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            DropdownMenuItem(text = { Text("Settings & appearance") }, leadingIcon = { Icon(Icons.Default.Settings, null) }, onClick = { expanded = false; showSettings = true })
                            DropdownMenuItem(text = { Text("Wallpapers") }, leadingIcon = { Icon(Icons.Default.Palette, null) }, onClick = { expanded = false; showWallpaperMenu = true })
                            DropdownMenuItem(text = { Text("About MelodyRise") }, leadingIcon = { Icon(Icons.Default.Info, null) }, onClick = { expanded = false; showAbout = true })
                            HorizontalDivider()
                            listOf("DARK" to "Dark mode", "LIGHT" to "Light mode", "SYSTEM" to "Follow system", "GLASS" to "Glassy theme", "12H" to "12-hour (AM/PM)", "24H" to "24-hour time").forEach { (value, label) ->
                                DropdownMenuItem(text = { Text(label) }, onClick = {
                                    if (value == "12H" || value == "24H") { timeFormat = value; uiPrefs.edit().putString("time_format", value).apply() }
                                    else { themeChoice = value; uiPrefs.edit().putString("theme", value).apply() }
                                    expanded = false
                                })
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.weight(1f)) {
                        Text(greetingLine, color = text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("Ready to set your next alarm?", color = muted, fontSize = 12.sp)
                    }
                    TextButton(onClick = { nameInput = uiPrefs.getString("display_name", "") ?: ""; showEditNameDialog = true }) { Text("Edit name", color = MintAccent, fontSize = 12.sp) }
                }
                Spacer(Modifier.height(14.dp))
                Card(colors = CardDefaults.cardColors(containerColor = if (glass) panel else if (light) Color(0xFFE9E4FF) else Color(0xFF302B50)), shape = RoundedCornerShape(24.dp), border = if (glass) androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.24f)) else null) {
                    Column(Modifier.fillMaxWidth().padding(20.dp)) {
                        Text("YOUR ALARMS", color = if (light) Color(0xFF5C4BA5) else MintAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                        Text("${alarms.count { it.enabled }} active", color = text, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Each alarm keeps its own song and schedule.", color = muted, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(18.dp))
                Text("CREATE AN ALARM", color = text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(22.dp), border = if (glass) androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.24f)) else null) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(onClick = { picker.launch(arrayOf("audio/mpeg", "audio/*")) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.MusicNote, null); Spacer(Modifier.width(8.dp)); Text(if (selectedName.isBlank()) "Choose MP3 song" else selectedName, maxLines = 1)
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = if (glass) Color.White.copy(alpha = if (light) 0.32f else 0.10f) else if (light) Color(0xFFF2EEFF) else Color(0xFF26223F)), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(), border = if (glass) androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.22f)) else null) {
                            Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("ALARM TIME", color = muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                                TextButton(onClick = { showTimePicker = true }) {
                                    Text(formatAlarmTime(hour, minute, timeFormat), color = text, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                                }
                                OutlinedButton(onClick = { showTimePicker = true }) {
                                    Icon(Icons.Default.Schedule, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("Choose time")
                                }
                                Text("Tap the time to open the clock picker", color = muted, fontSize = 11.sp)
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text("Repeat daily", color = text, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                Text("${if (daily) "Repeats every day" else "Rings once"}", color = muted, fontSize = 11.sp)
                            }
                            Switch(checked = daily, onCheckedChange = { daily = it })
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Quick adjust selected time:", color = muted, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterVertically))
                            listOf(1, 5, 10).forEach { amount ->
                                OutlinedButton(
                                    onClick = {
                                        val total = (hour * 60 + minute + amount) % (24 * 60)
                                        hour = total / 60
                                        minute = total % 60
                                    },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp)
                                ) { Text("+${amount} min", maxLines = 1, fontSize = 11.sp) }
                            }
                        }
                        Text("Time format: ${if (timeFormat == "12H") "12-hour (AM/PM)" else "24-hour"}", color = muted, fontSize = 11.sp)
                        Button(onClick = {
                            val uri = selectedUri
                            if (uri == null) { message = "Choose an MP3 first."; return@Button }
                            val id = AlarmStore.nextId(context)
                            val a = SongAlarm(id, hour, minute, uri.toString(), selectedName.ifBlank { "MP3 song" }, daily, true, "ONCE")
                            AlarmStore.save(context, a)
                            AlarmStore.schedule(context, a)
                            alarms = AlarmStore.all(context)
                            message = "Alarm saved. Song plays once to completion by default."
                        }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                            Icon(Icons.Default.AddAlarm, null); Spacer(Modifier.width(8.dp)); Text("ADD ALARM", fontWeight = FontWeight.Bold)
                        }
                        Text(message, color = muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text("SCHEDULED ALARMS", color = text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                if (alarms.isEmpty()) {
                    Text("No alarms yet. Add your first alarm above.", color = muted, modifier = Modifier.padding(vertical = 12.dp))
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 18.dp)) {
                        alarms.sortedWith(compareBy<SongAlarm> { it.hour }.thenBy { it.minute }).forEach { alarm ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = if (glass) panel.copy(alpha = 0.72f) else panel),
                                shape = RoundedCornerShape(18.dp),
                                border = if (glass) androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.32f)) else null
                            ) {
                                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(formatAlarmTime(alarm.hour, alarm.minute, timeFormat), color = text, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                                        Text(alarm.songName, color = muted, fontSize = 12.sp, maxLines = 1)
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Schedule, null, tint = accent, modifier = Modifier.size(14.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text(if (alarm.daily) "Daily" else "One time", color = muted, fontSize = 11.sp)
                                        }
                                    }
                                    Switch(checked = alarm.enabled, onCheckedChange = { on ->
                                        AlarmStore.setEnabled(context, alarm.id, on)
                                        alarms = AlarmStore.all(context)
                                    })
                                    IconButton(onClick = { AlarmStore.remove(context, alarm.id); alarms = AlarmStore.all(context); message = "Alarm deleted." }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete alarm", tint = Color(0xFFE87989))
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (showTimePicker) {
                val pickerState = rememberTimePickerState(
                    initialHour = hour,
                    initialMinute = minute,
                    is24Hour = timeFormat == "24H"
                )
                AlertDialog(
                    onDismissRequest = { showTimePicker = false },
                    title = { Text("Select alarm time", fontWeight = FontWeight.Bold) },
                    text = {
                        Column(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            TimePicker(state = pickerState)
                            Spacer(Modifier.height(8.dp))
                            Text(if (timeFormat == "12H") "Choose hour, minute, and AM/PM" else "Choose hour and minute", color = muted, fontSize = 12.sp)
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            hour = pickerState.hour
                            minute = pickerState.minute
                            showTimePicker = false
                        }) { Text("OK") }
                    },
                    dismissButton = {
                        TextButton(onClick = { showTimePicker = false }) { Text("Cancel") }
                    }
                )
            }
            if (showNameDialog || showEditNameDialog) {
                AlertDialog(
                    onDismissRequest = {
                        if (showEditNameDialog) showEditNameDialog = false
                        else { showNameDialog = false; uiPrefs.edit().putBoolean("name_prompt_seen", true).apply() }
                    },
                    title = { Text(if (showEditNameDialog) "Change your name" else "Welcome to Full Song Alarm") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("What should we call you? Your name stays on this device.")
                            OutlinedTextField(value = nameInput, onValueChange = { nameInput = it.take(40) }, singleLine = true, label = { Text("Your name (optional)") })
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            uiPrefs.edit().putString("display_name", nameInput.trim()).putBoolean("name_prompt_seen", true).apply()
                            showNameDialog = false
                            showEditNameDialog = false
                        }) { Text("Save") }
                    },
                    dismissButton = {
                        TextButton(onClick = {
                            if (showEditNameDialog) showEditNameDialog = false else showNameDialog = false
                            uiPrefs.edit().putBoolean("name_prompt_seen", true).apply()
                        }) { Text("Skip") }
                    }
                )
            }
            if (showSettings) {
                AlertDialog(
                    onDismissRequest = { showSettings = false },
                    title = { Text("Appearance & settings", fontWeight = FontWeight.Bold) },
                    text = {
                        Column(Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("GLASS INTENSITY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = muted, letterSpacing = 1.sp)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Slider(value = glassStrength, onValueChange = { glassStrength = it; uiPrefs.edit().putFloat("glass_strength", it).apply() }, valueRange = 0.12f..0.82f, modifier = Modifier.weight(1f))
                                Text("${(glassStrength * 100).toInt()}%", color = text, fontSize = 12.sp)
                            }
                            Text("Choose a theme from the three-dot menu. Glass intensity applies to the Glassy theme.", color = muted, fontSize = 12.sp)
                            HorizontalDivider()
                            Text("ACCENT COLOUR", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = muted, letterSpacing = 1.sp)
                            val colors = listOf("#9B8CFF", "#69D6C5", "#FF8FA3", "#FFB86B", "#72B7FF", "#E7E9F0", "#C4E86B", "#D78BFF")
                            colors.chunked(4).forEach { rowColors ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    rowColors.forEach { hex ->
                                        val color = Color(android.graphics.Color.parseColor(hex))
                                        Box(Modifier.weight(1f).size(42.dp).background(color, CircleShape).then(if (accentHex == hex) Modifier.padding(3.dp).background(color, CircleShape) else Modifier), contentAlignment = Alignment.Center) {
                                            TextButton(onClick = { accentHex = hex; uiPrefs.edit().putString("accent_hex", hex).apply() }, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(0.dp)) { Text(if (accentHex == hex) "✓" else "", color = Color.Black, fontWeight = FontWeight.Bold) }
                                        }
                                    }
                                }
                            }
                            Text("TEXT COLOUR", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = muted, letterSpacing = 1.sp)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                listOf("#FFFFFF", "#20202A", "#D9E4FF", "#FFE4B8", "#B7FFE8").forEach { hex ->
                                    Box(Modifier.weight(1f).height(38.dp).background(Color(android.graphics.Color.parseColor(hex)), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                                        TextButton(onClick = { textHex = hex; uiPrefs.edit().putString("text_hex", hex).apply() }, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(0.dp)) { Text(if (textHex == hex) "✓" else "", color = Color.Black, fontWeight = FontWeight.Bold) }
                                    }
                                }
                            }
                            TextButton(onClick = { textHex = ""; uiPrefs.edit().remove("text_hex").apply() }, modifier = Modifier.fillMaxWidth()) { Text("Use automatic text colour") }
                            Text("Custom colour (HEX)", color = text, fontSize = 13.sp)
                            var customHex by remember { mutableStateOf(accentHex) }
                            OutlinedTextField(value = customHex, onValueChange = { customHex = it.take(7).uppercase() }, label = { Text("Example: #9B8CFF") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            OutlinedButton(onClick = {
                                val valid = customHex.matches(Regex("#[0-9A-F]{6}"))
                                if (valid) { accentHex = customHex; uiPrefs.edit().putString("accent_hex", customHex).apply(); message = "Accent colour updated." }
                                else message = "Enter a valid HEX colour such as #9B8CFF."
                            }, modifier = Modifier.fillMaxWidth()) { Text("Apply custom colour") }
                            HorizontalDivider()
                            Text("TIME DISPLAY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = muted, letterSpacing = 1.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = timeFormat == "12H", onClick = { timeFormat = "12H"; uiPrefs.edit().putString("time_format", "12H").apply() }, label = { Text("12-hour AM/PM") })
                                FilterChip(selected = timeFormat == "24H", onClick = { timeFormat = "24H"; uiPrefs.edit().putString("time_format", "24H").apply() }, label = { Text("24-hour") })
                            }
                            OutlinedButton(onClick = { themeChoice = "GLASS"; uiPrefs.edit().putString("theme", "GLASS").apply() }, modifier = Modifier.fillMaxWidth()) { Text("Enable glassy theme") }
                            TextButton(onClick = { glassStrength = 0.48f; accentHex = "#9B8CFF"; textHex = ""; themeChoice = "DARK"; timeFormat = "12H"; uiPrefs.edit().putFloat("glass_strength", 0.48f).putString("accent_hex", "#9B8CFF").remove("text_hex").putString("theme", "DARK").putString("time_format", "12H").apply() }, modifier = Modifier.fillMaxWidth()) { Text("Reset appearance defaults") }
                        }
                    },
                    confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Done") } }
                )
            }
            if (showAbout) {
                AlertDialog(
                    onDismissRequest = { showAbout = false },
                    icon = { Icon(Icons.Default.MusicNote, null, tint = accent, modifier = Modifier.size(34.dp)) },
                    title = { Text("MelodyRise", fontWeight = FontWeight.ExtraBold) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Wake Up to Your Favourite Music", color = accent, fontWeight = FontWeight.SemiBold)
                            Text("Turn songs on your phone into scheduled alarms.")
                            Text("FEATURES", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("""• Multiple alarms with individual songs
• Daily or one-time schedules
• Full-song playback mode
• Quick time adjustments
• Local wallpapers and glass theme
• Light, dark and system themes
• 12-hour AM/PM and 24-hour time
• Alarm permission guidance""")
                            HorizontalDivider()
                            Text("Version 2.4.0 (24)", fontWeight = FontWeight.Bold)
                            Text("Settings are stored on this device. Alarm timing and full-screen behaviour depend on Android permissions and device settings.", color = muted, fontSize = 12.sp)
                        }
                    },
                    confirmButton = { TextButton(onClick = { showAbout = false }) { Text("Close") } }
                )
            }
            if (showWallpaperMenu) {
                AlertDialog(
                    onDismissRequest = { showWallpaperMenu = false },
                    title = { Text("Choose background") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("AURORA" to "Aurora (default)", "OCEAN" to "Ocean blue", "SUNSET" to "Sunset glow", "FOREST" to "Forest green", "MIDNIGHT" to "Midnight purple").forEach { (value, label) ->
                                TextButton(onClick = {
                                    wallpaperChoice = value
                                    uiPrefs.edit().putString("wallpaper", value).apply()
                                    showWallpaperMenu = false
                                    message = "$label wallpaper selected."
                                }, modifier = Modifier.fillMaxWidth()) {
                                    Text((if (wallpaperChoice == value) "✓  " else "    ") + label, modifier = Modifier.fillMaxWidth())
                                }
                            }
                            OutlinedButton(onClick = { showWallpaperMenu = false; wallpaperPicker.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) {
                                Text("Choose from this phone")
                            }
                            if (wallpaperChoice == "LOCAL" && wallpaperUri != null) {
                                TextButton(onClick = {
                                    wallpaperChoice = "AURORA"
                                    uiPrefs.edit().putString("wallpaper", "AURORA").apply()
                                    showWallpaperMenu = false
                                }, modifier = Modifier.fillMaxWidth()) { Text("Remove local wallpaper") }
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { showWallpaperMenu = false }) { Text("Done") } }
                )
            }
          }
        }
    }
}

@Composable
private fun TimePickerPart(label: String, value: String, down: () -> Unit, up: () -> Unit, text: Color, muted: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = down, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(26.dp)) { Text("−", color = Lilac, fontSize = 18.sp) }
            Text(value, color = text, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = up, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(26.dp)) { Text("+", color = Lilac, fontSize = 18.sp) }
        }
    }
}

private fun displayName(context: Context, uri: Uri): String? = try {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
        if (it.moveToFirst()) it.getString(0) else null
    }
} catch (_: Exception) { null }


private fun formatAlarmTime(hour: Int, minute: Int, format: String): String {
    return if (format == "12H") {
        val displayHour = if (hour % 12 == 0) 12 else hour % 12
        String.format(Locale.getDefault(), "%d:%02d %s", displayHour, minute, if (hour < 12) "AM" else "PM")
    } else {
        String.format(Locale.getDefault(), "%02d:%02d", hour, minute)
    }
}
