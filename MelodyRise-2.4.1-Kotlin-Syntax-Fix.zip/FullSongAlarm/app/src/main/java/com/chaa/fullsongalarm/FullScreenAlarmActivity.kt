package com.chaa.fullsongalarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar
import java.util.Locale

class FullScreenAlarmActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        val id = intent.getIntExtra("alarm_id", -1)
        val alarm = AlarmStore.all(this).firstOrNull { it.id == id }
        val prefs = getSharedPreferences("ui", Context.MODE_PRIVATE)
        val displayName = prefs.getString("display_name", "")?.trim().orEmpty()
        val wallpaperChoice = prefs.getString("wallpaper", "AURORA") ?: "AURORA"
        val wallpaperUri = prefs.getString("wallpaper_uri", null)
        val timeFormat = prefs.getString("time_format", "12H") ?: "12H"
        val localBitmap = if (wallpaperChoice == "LOCAL" && wallpaperUri != null) {
            try { contentResolver.openInputStream(Uri.parse(wallpaperUri))?.use { BitmapFactory.decodeStream(it)?.asImageBitmap() } } catch (_: Exception) { null }
        } else null
        setContent {
            val greeting = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
                in 5..11 -> "Good morning"
                in 12..16 -> "Good afternoon"
                in 17..20 -> "Good evening"
                else -> "Hello"
            }
            val wallpaperBrush = when (wallpaperChoice) {
                "OCEAN" -> Brush.verticalGradient(listOf(Color(0xFF064E68), Color(0xFF101B3C), Color(0xFF10131F)))
                "SUNSET" -> Brush.verticalGradient(listOf(Color(0xFFFF9A76), Color(0xFF8D477D), Color(0xFF24264B)))
                "FOREST" -> Brush.verticalGradient(listOf(Color(0xFF174A3A), Color(0xFF172D32), Color(0xFF10131F)))
                "MIDNIGHT" -> Brush.verticalGradient(listOf(Color(0xFF34306D), Color(0xFF16182C), Color(0xFF10131F)))
                else -> Brush.linearGradient(listOf(Color(0xFF392F70), Color(0xFF151A31), Color(0xFF10131F)))
            }
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFB7A9FF), secondary = Color(0xFF9DF0D0))) {
                Box(Modifier.fillMaxSize()) {
                    if (localBitmap != null) {
                        Image(bitmap = localBitmap, contentDescription = "Alarm wallpaper", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    } else {
                        Box(Modifier.fillMaxSize().background(wallpaperBrush))
                    }
                    Box(Modifier.fillMaxSize().background(Color(0xFF080A14).copy(alpha = 0.24f)))
                    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Icon(Icons.Default.Alarm, null, tint = Color(0xFF9DF0D0), modifier = Modifier.size(64.dp))
                        Spacer(Modifier.height(18.dp))
                        Text(if (displayName.isNotBlank()) "$greeting, $displayName!" else greeting, color = Color.White.copy(alpha = 0.92f), fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(10.dp))
                        Text("TIME TO WAKE UP", color = Color(0xFF9DF0D0), fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        if (alarm != null) {
                            Spacer(Modifier.height(8.dp))
                            Text(formatPopupTime(alarm.hour, alarm.minute, timeFormat), color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Spacer(Modifier.height(18.dp))
                        Surface(color = Color.White.copy(alpha = 0.14f), shape = RoundedCornerShape(28.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))) {
                            Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(alarm?.songName ?: "Your song is playing", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("Your song plays until it finishes", color = Color.White.copy(alpha = 0.78f), fontSize = 13.sp)
                                Spacer(Modifier.height(24.dp))
                                Button(onClick = {
                                    stopService(Intent(this@FullScreenAlarmActivity, MusicPlaybackService::class.java).setAction(MusicPlaybackService.ACTION_STOP))
                                    finish()
                                }, modifier = Modifier.fillMaxWidth().height(60.dp), shape = RoundedCornerShape(18.dp)) {
                                    Icon(Icons.Default.Stop, null); Spacer(Modifier.width(8.dp)); Text("STOP ALARM", fontWeight = FontWeight.ExtraBold)
                                }
                                Spacer(Modifier.height(12.dp))
                                OutlinedButton(onClick = {
                                    if (id >= 0) {
                                        val manager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                                        val snoozeIntent = Intent(this@FullScreenAlarmActivity, AlarmReceiver::class.java)
                                            .putExtra("alarm_id", id).putExtra("snooze", true)
                                        val pending = PendingIntent.getBroadcast(this@FullScreenAlarmActivity, 8000 + id, snoozeIntent,
                                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                                        val trigger = System.currentTimeMillis() + 5 * 60 * 1000L
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
                                        else manager.set(AlarmManager.RTC_WAKEUP, trigger, pending)
                                    }
                                    stopService(Intent(this@FullScreenAlarmActivity, MusicPlaybackService::class.java).setAction(MusicPlaybackService.ACTION_STOP))
                                    finish()
                                }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)) {
                                    Text("SNOOZE 5 MIN", fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatPopupTime(hour: Int, minute: Int, format: String): String = if (format == "12H") {
    val shownHour = if (hour % 12 == 0) 12 else hour % 12
    String.format(Locale.getDefault(), "%d:%02d %s", shownHour, minute, if (hour < 12) "AM" else "PM")
} else {
    String.format(Locale.getDefault(), "%02d:%02d", hour, minute)
}
