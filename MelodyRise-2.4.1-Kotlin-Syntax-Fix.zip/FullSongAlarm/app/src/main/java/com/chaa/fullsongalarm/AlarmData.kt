package com.chaa.fullsongalarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class SongAlarm(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val songUri: String,
    val songName: String,
    val daily: Boolean,
    val enabled: Boolean = true,
    val repeatMode: String = "ONCE"
)

object AlarmStore {
    private const val PREFS = "full_song_alarm_v2"
    private const val KEY = "alarms"
    private const val NEXT_ID = "next_id"

    fun all(context: Context): List<SongAlarm> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                SongAlarm(o.getInt("id"), o.getInt("hour"), o.getInt("minute"),
                    o.getString("songUri"), o.optString("songName", "MP3 track"),
                    o.optBoolean("daily", true), o.optBoolean("enabled", true),
                    o.optString("repeatMode", "ONCE"))
            }
        } catch (_: Exception) { emptyList() }
    }

    fun save(context: Context, alarm: SongAlarm) {
        val items = all(context).filterNot { it.id == alarm.id } + alarm
        write(context, items)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("alarm_uri_${alarm.id}", alarm.songUri)
            .putString("alarm_name_${alarm.id}", alarm.songName)
            .apply()
    }

    fun remove(context: Context, id: Int) {
        cancel(context, id)
        write(context, all(context).filterNot { it.id == id })
    }

    fun setEnabled(context: Context, id: Int, enabled: Boolean) {
        val item = all(context).firstOrNull { it.id == id } ?: return
        val changed = item.copy(enabled = enabled)
        save(context, changed)
        if (enabled) schedule(context, changed) else cancel(context, id)
    }

    fun nextId(context: Context): Int {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val id = p.getInt(NEXT_ID, 1)
        p.edit().putInt(NEXT_ID, id + 1).apply()
        return id
    }

    private fun write(context: Context, items: List<SongAlarm>) {
        val arr = JSONArray()
        items.sortedBy { it.id }.forEach { a ->
            arr.put(JSONObject().put("id", a.id).put("hour", a.hour).put("minute", a.minute)
                .put("songUri", a.songUri).put("songName", a.songName).put("daily", a.daily)
                .put("enabled", a.enabled).put("repeatMode", a.repeatMode))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun schedule(context: Context, alarm: SongAlarm) {
        if (!alarm.enabled) return
        val now = Calendar.getInstance()
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, alarm.hour)
            set(Calendar.MINUTE, alarm.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)
        }
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = alarmPendingIntent(context, alarm.id)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
        } else {
            manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
        }
    }

    fun cancel(context: Context, id: Int) {
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        manager.cancel(alarmPendingIntent(context, id))
    }

    private fun alarmPendingIntent(context: Context, id: Int): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).putExtra("alarm_id", id)
        return PendingIntent.getBroadcast(context, id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}
