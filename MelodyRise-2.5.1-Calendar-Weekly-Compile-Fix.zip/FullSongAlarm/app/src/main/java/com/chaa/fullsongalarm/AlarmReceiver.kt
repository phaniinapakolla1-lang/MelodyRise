package com.chaa.fullsongalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val id = intent?.getIntExtra("alarm_id", -1) ?: -1
        if (id < 0) return
        val isSnooze = intent?.getBooleanExtra("snooze", false) ?: false
        val alarm = AlarmStore.all(context).firstOrNull { it.id == id && (it.enabled || isSnooze) } ?: return

        // A scheduled alarm may start a foreground service even when the app UI is closed.
        val serviceIntent = Intent(context, MusicPlaybackService::class.java).putExtra("alarm_id", id)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(serviceIntent)
            else context.startService(serviceIntent)
        } catch (_: Exception) {
            // Keep the alarm enabled if Android blocks service startup so it can be restored
            // when the app is next opened or after a reboot.
            return
        }

        if (!isSnooze) {
            if (alarm.scheduleType == "DAILY" || alarm.scheduleType == "CALENDAR" || alarm.scheduleType == "WEEKLY") {
                // Re-arm only the next matching occurrence; CALENDAR never fills intervening dates.
                AlarmStore.schedule(context, alarm)
            } else {
                AlarmStore.setEnabled(context, id, false)
            }
        }
    }
}
