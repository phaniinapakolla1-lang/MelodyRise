package com.chaa.fullsongalarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * scheduleType: ONCE (legacy), DAILY (legacy), CALENDAR (specific dates), WEEKLY (weekdays).
 * dateKeys are ISO local dates (yyyy-MM-dd); weekdays use Calendar.MONDAY..SUNDAY.
 */
data class SongAlarm(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val songUri: String,
    val songName: String,
    val daily: Boolean,
    val enabled: Boolean = true,
    val repeatMode: String = "ONCE",
    val dateKeys: List<String> = emptyList(),
    val weekdays: List<Int> = emptyList()
) {
    val scheduleType: String get() = when {
        repeatMode == "CALENDAR" -> "CALENDAR"
        repeatMode == "WEEKLY" -> "WEEKLY"
        daily || repeatMode == "DAILY" -> "DAILY"
        else -> "ONCE"
    }
}

object AlarmStore {
    private const val PREFS = "full_song_alarm_v2"
    private const val KEY = "alarms"
    private const val NEXT_ID = "next_id"
    private val dateFormat get() = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun dateKey(calendar: Calendar): String = dateFormat.format(calendar.time)
    fun parseDate(key: String): Calendar? = try {
        Calendar.getInstance().apply {
            time = dateFormat.parse(key) ?: return null
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
    } catch (_: Exception) { null }

    fun all(context: Context): List<SongAlarm> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val mode = o.optString("repeatMode", if (o.optBoolean("daily", true)) "DAILY" else "ONCE")
                val dates = o.optJSONArray("dateKeys")?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList()
                val days = o.optJSONArray("weekdays")?.let { a -> (0 until a.length()).map { a.getInt(it) } } ?: emptyList()
                SongAlarm(o.getInt("id"), o.getInt("hour"), o.getInt("minute"),
                    o.getString("songUri"), o.optString("songName", "MP3 track"),
                    o.optBoolean("daily", mode == "DAILY"), o.optBoolean("enabled", true),
                    mode, dates, days)
            }
        } catch (_: Exception) { emptyList() }
    }

    fun save(context: Context, alarm: SongAlarm) {
        val items = all(context).filterNot { it.id == alarm.id } + alarm
        write(context, items)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("alarm_uri_${alarm.id}", alarm.songUri)
            .putString("alarm_name_${alarm.id}", alarm.songName).apply()
    }

    fun remove(context: Context, id: Int) {
        cancel(context, id)
        write(context, all(context).filterNot { it.id == id })
    }

    fun setEnabled(context: Context, id: Int, enabled: Boolean) {
        val item = all(context).firstOrNull { it.id == id } ?: return
        val changed = item.copy(enabled = enabled)
        save(context, changed)
        if (enabled) schedule(context, changed) else cancel(context, id)
    }

    fun nextId(context: Context): Int {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val id = p.getInt(NEXT_ID, 1)
        p.edit().putInt(NEXT_ID, id + 1).apply()
        return id
    }

    private fun write(context: Context, items: List<SongAlarm>) {
        val arr = JSONArray()
        items.sortedBy { it.id }.forEach { a ->
            val dates = JSONArray().also { out -> a.dateKeys.distinct().sorted().forEach(out::put) }
            val days = JSONArray().also { out -> a.weekdays.distinct().sorted().forEach(out::put) }
            arr.put(JSONObject().put("id", a.id).put("hour", a.hour).put("minute", a.minute)
                .put("songUri", a.songUri).put("songName", a.songName).put("daily", a.daily)
                .put("enabled", a.enabled).put("repeatMode", a.scheduleType)
                .put("dateKeys", dates).put("weekdays", days))
    }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    private fun nextOccurrence(alarm: SongAlarm, from: Calendar = Calendar.getInstance()): Calendar? {
        val now = from.clone() as Calendar
        val candidate = Calendar.getInstance().apply {
            timeInMillis = now.timeInMillis
            set(Calendar.HOUR_OF_DAY, alarm.hour); set(Calendar.MINUTE, alarm.minute)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        // Search date-by-date. It intentionally does not fill gaps between selected calendar dates.
        for (offset in 0..3660) {
            val day = (candidate.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, offset) }
            if (day.timeInMillis <= now.timeInMillis) continue
            val allowed = when (alarm.scheduleType) {
                "CALENDAR" -> dateKey(day) in alarm.dateKeys
                "WEEKLY" -> day.get(Calendar.DAY_OF_WEEK) in alarm.weekdays
                "DAILY" -> true
                else -> offset == 0
            }
            if (allowed) return day
            if (alarm.scheduleType == "ONCE") return null
        }
        return null
    }

    fun schedule(context: Context, alarm: SongAlarm) {
        cancel(context, alarm.id)
        if (!alarm.enabled) return
        val next = nextOccurrence(alarm) ?: return
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = alarmPendingIntent(context, alarm.id)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
        } else {
            manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
        }
    }

    /** Recreate AlarmManager entries after reboot, app replacement, or clock/time-zone changes. */
    fun rescheduleEnabled(context: Context) {
        all(context).forEach { alarm ->
            cancel(context, alarm.id)
            if (alarm.enabled) schedule(context, alarm)
        }
    }

    fun cancel(context: Context, id: Int) {
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        manager.cancel(alarmPendingIntent(context, id))
    }

    private fun alarmPendingIntent(context: Context, id: Int): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).putExtra("alarm_id", id)
        return PendingIntent.getBroadcast(context, id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}
