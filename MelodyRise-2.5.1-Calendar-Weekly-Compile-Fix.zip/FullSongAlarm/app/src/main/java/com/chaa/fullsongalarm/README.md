# MelodyRise 2.5.0

Wake Up to Your Favourite Music.

## Included in this update
- MelodyRise app label and a custom adaptive launcher icon combining an alarm clock and music note.
- Version metadata: 2.4.0 (version code 24).
- Three-dot menu for settings, wallpapers, About, themes, and time format.
- Appearance settings with glass-intensity slider, accent colour presets, custom HEX accent colour, text colour presets, and automatic text-colour reset.
- Existing alarm creation, selected song, schedule, wallpaper choices, greeting, permission gate, and alarm list retained from 2.3.2 source.
- About screen with app description and feature overview.

## Build on Windows
1. Open the `FullSongAlarm` folder in Android Studio.
2. Ensure `local.properties` points to your Android SDK, for example: `sdk.dir=C:/Users/inapa/AppData/Local/Android/Sdk`. Adjust this path if your Windows username or SDK location differs.
3. Let Android Studio sync Gradle.
4. Build using `gradlew.bat assembleDebug` from the project folder.
5. APK output, if the build succeeds: `app\build\outputs\apk\debug\app-debug.apk`.

## Important
This source package has not been compiled or device-tested in this environment. The build runner could not download Gradle because internet access was unavailable. Build and test it in Android Studio before installing or distributing it. Verify alarm scheduling, playback, lock-screen behavior, wallpaper persistence, and settings on your Android device.


## Calendar and weekly scheduling update
- Calendar alarms store a list of explicit local dates (`yyyy-MM-dd`) and schedule only the next selected date. They do not repeat on intervening days.
- Weekly alarms store selected weekdays (Monday through Sunday) and schedule the next matching weekday.
- Existing `DAILY` and `ONCE` records are read using their old fields and retained during migration.
- Editing an alarm preserves its stored past calendar dates; past dates are visible but disabled in the date picker. Removing an alarm remains an explicit user action.
- Date/time scheduling uses the device's local calendar and is recalculated on boot, app replacement, clock changes, timezone changes, and exact-alarm permission changes.

This source update has not been compiled or device-tested here. Build it in Android Studio with Gradle sync, then test calendar dates, weekly recurrence, reboot restoration, lock-screen playback, and permission behavior on your device.
